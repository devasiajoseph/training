package jproject;

 public class Area
{
    
    public Area(){
	System.out.println("Area initilaized");
    }
    
    public static double getRectangleArea(double length, double breadth)
    {
	
        return length * breadth;
    }

    
}
